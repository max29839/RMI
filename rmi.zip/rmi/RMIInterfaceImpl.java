package rmi;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

public class RMIInterfaceImpl  extends UnicastRemoteObject implements RMIInterface {
	
	private static final long serialVersionUID = 1L;
	public RMIInterfaceImpl() throws RemoteException{

	}
	public int remoteMethod(int a, int b){
		try{
			int result = a+b;
			return result;
			
		}catch(Exception e){
			System.out.println(e.getMessage());
			return 0;
		}
	}
}


