package rmi;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
public class RMIClient {
	public static void main(String[] args) throws MalformedURLException, RemoteException, NotBoundException {
		RMIInterface obj = (RMIInterface)Naming.lookup("RMIServer");
		try{
			System.out.println('\n'+"Client call to :"+obj+'\n');
			int a = Integer.parseInt(args[0]);
			int b = Integer.parseInt(args[1]);
			int temp = obj.remoteMethod(a, b);
			System.out.println("Result :"+a+"+"+b+"="+temp);
		}catch(Exception e){
			System.out.println(e);
		}
	}
}